import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { NgIf, NgFor } from '@angular/common';
import { FormsModule } from '@angular/forms'; // ✅ Import FormsModule
import { MatIconModule } from '@angular/material/icon';
import { Router } from '@angular/router'; 
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-page-access',
  standalone: true,
  imports: [
    NgIf, NgFor,
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatIconModule,
    MatButtonModule,
    FormsModule 
  ],
  templateUrl: './page-access.component.html',
  styleUrl: './page-access.component.css'
})
export class PageAccessComponent implements OnInit {
  showForm = false;
  isEditing = false;
  editingIndex: number | null = null;
  
  subscriptionPlans: string[] = ['Basic', 'Standard', 'Premium', 'Free'];
  displayedColumns: string[] = ['plan', 'page', 'actions'];
  apiUrl = 'https://localhost:44320/api/Service/SQLLOADEXEC';
  apiUrlpost = 'https://localhost:44320/api/Service/GENERICSQLEXEC';
  storedProcedureName = '[dbo].[sp_Select_PageAccess]';
  accessData = new MatTableDataSource<any>([]);

  newPage = { AccessID: 0, LicenseType: '', PageName: '' };

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit() {
    this.fetchAccessData();
  }
  

  fetchAccessData() {
    const params = { spname: this.storedProcedureName };
  
    this.http.get<any[]>(this.apiUrl, { params }).subscribe(
      (data) => {
        console.log('Fetched page access', data);
        this.accessData.data = data;
      },
      (error) => {
        console.error('Error fetching page access', error);
      }
    );
  }


  toggleForm() {
    this.showForm = true;
    this.isEditing = false;
    this.newPage = { AccessID: 0, LicenseType: '', PageName: '' };
  }

  goBack() {
    this.router.navigate(['/']); 
  }
  saveOrUpdatePage() {
    if (this.isEditing) {
      this.updatePage();  // Calls the update method if editing
    } else {
      this.savePage();  // Calls the save method if creating
    }
  }


  // saveOrUpdatePage() {
  //   if (!this.newPage.plan || !this.newPage.page) return;

  //   if (this.isEditing && this.editingIndex !== null) {
  //     this.accessData.data[this.editingIndex] = { ...this.newPage };
  //   } else {
  //     this.accessData.data = [this.newPage, ...this.accessData.data];
  //   }

  //   this.newPage = { plan: '', page: '' };
  //   this.showForm = false;
  //   this.isEditing = false;
  // }
  updatePage() {
    if (!this.newPage.AccessID || !this.newPage.LicenseType || !this.newPage.PageName) {
      alert('Please fill in all required fields.');
      return;
    }
  
    const requestData = {
      jsonFileparams: JSON.stringify([{ 
        AccessID: this.newPage.AccessID,  // Pass AccessID for updating
        LicenseType: this.newPage.LicenseType, 
        PageName: this.newPage.PageName, 
        Updatedby: "Admin"  // Change this dynamically if needed
      }]),
      spname: "[dbo].[sp_Update_PageAccess]"  // Call update stored procedure
    };
  
    console.log("Sending Data to API for Update:", requestData);
  
    this.http.post(this.apiUrlpost, requestData, { responseType: 'text' }).subscribe(
      (response) => {
        console.log("API Response:", response);
        if (response.trim().toLowerCase() === "success") {
          alert("Page access updated successfully!");
          this.newPage = { LicenseType: '', PageName: '', AccessID: 0 };
          this.showForm = false;
          this.isEditing = false;
          this.fetchAccessData(); // Refresh table data
        } else {
          alert("Unexpected response from the server.");
        }
      },
      (error) => {
        console.error("API Error:", error);
        alert("Error updating page access.");
      }
    );
  }
  savePage() {
    if (!this.newPage.LicenseType || !this.newPage.PageName) {
        alert('Please fill in all required fields.');
        return;
    }

    const requestData = {
        jsonFileparams: JSON.stringify([{ 
            LicenseType: this.newPage.LicenseType, 
            PageName: this.newPage.PageName, 
            Createdby: "Admin"  // Change this dynamically if needed
        }]),
        spname: "[dbo].[sp_Insert_PageAccess]"
    };

    console.log("Sending Data to API:", requestData);

    this.http.post(this.apiUrlpost, requestData, { responseType: 'text' }).subscribe(
        (response) => {
            console.log("API Response:", response);
            if (response.trim().toLowerCase() === "success") {
                alert("Page access added successfully!");
                this.newPage = { AccessID: 0, LicenseType: '', PageName: '' };
                this.showForm = false;
                this.isEditing = false;
                this.fetchAccessData(); // Refresh table data
            } else {
                alert("Unexpected response from the server.");
            }
        },
        (error) => {
            console.error("API Error:", error);
            alert("Error adding page access.");
        }
    );
}

editPage(element: any, index: number) {
  console.log('Editing page:', element);  // Log the element data
  this.newPage = { ...element };  // Now this includes accessId
  this.editingIndex = index;
  this.showForm = true;
  this.isEditing = true;
  console.log('newPage after editPage:', this.newPage);  // Check if newPage is populated
}

  deletePage(index: number) {
    const data = this.accessData.data;
    data.splice(index, 1);
    this.accessData.data = [...data];
  }

  cancelEdit() {
    this.showForm = false;
    this.isEditing = false;
    this.newPage = { AccessID: 0, LicenseType: '', PageName: '' };
  }
}