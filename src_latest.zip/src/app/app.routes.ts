import { Routes } from '@angular/router';
import { CustomerComponent } from './customer/customer.component';
import { AddCustomerComponent } from './add-cutomer/add-cutomer.component';
import { AccessDeniedComponent } from './access-denied/access-denied.component';
import { PageAccessComponent } from './page-access/page-access.component';
import { ConfirmSnackbarComponent } from './confirm-snackbar/confirm-snackbar.component';

export const routes: Routes = [
    { path: '', redirectTo: 'customers', pathMatch: 'full' }, 
    { path: 'customers', component: CustomerComponent },
    { path: 'add-cutomer', component: AddCustomerComponent },
    { path: 'access-denied', component: AccessDeniedComponent },
    { path: 'page-access', component: PageAccessComponent },
    { path: 'confirm-snackbar', component: ConfirmSnackbarComponent }
  ];
