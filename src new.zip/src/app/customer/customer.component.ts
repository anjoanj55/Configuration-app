import { Component } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router'; 
import { CommonModule } from '@angular/common'; // ✅ Import this
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-customer',
  standalone: true,
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css'],
  imports: [
    CommonModule, // ✅ Add this line
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class CustomerComponent {
  customers: any[] = [];
  displayedColumns: string[] = ['id', 'name', 'phone', 'address', 'email', 'actions'];
  apiUrl = 'https://localhost:44320/api/Service/SQLLOADEXEC'; 
  storedProcedureName = '[dbo].[sp_select_customer]'; 

  constructor(
    private snackBar: MatSnackBar,
    private router: Router,
    private http: HttpClient // ✅ Ensure this is injected
  ) {}

  ngOnInit(): void {
    this.loadCustomers();
  }

  loadCustomers() {
    const params = { spname: this.storedProcedureName }; // 🔹 Use spname as query param
  
    this.http.get<any[]>(this.apiUrl, { params }).subscribe(
      (data) => {
        console.log('Fetched Customers:', data); // 🔹 Log data to console
        this.customers = data;
      },
      (error) => {
        console.error('Error fetching customers:', error);
      }
    );
  }

  openAddDialog() {
    this.router.navigate(['/add-cutomer']);
  }

  deleteCustomer(id: number | null) {
    this.customers = this.customers.filter(c => c.id !== id);
    this.snackBar.open('Customer Deleted', 'Close', { duration: 2000 });
  }
}
